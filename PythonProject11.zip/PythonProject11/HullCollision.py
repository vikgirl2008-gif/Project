class HullCollision:

    def __init__(self, points: list[HullPoint]):
            self.points = points

    def get_bounding_box(self) -> tuple[float, float, float, float]:
            xs = [p.x for p in self.points]
            ys = [p.y for p in self.points]
            return min(xs), max(xs), min(ys), max(ys)

    def visualize(self) -> str:
            min_x, max_x, min_y, max_y = self.get_bounding_box()

            width = int(max_x - min_x) + 3
            height = int(max_y - min_y) + 3

            grid = [['.' for _ in range(width)] for _ in range(height)]

            for p in self.points:
                grid_x = int(p.x - min_x) + 1
                grid_y = int(max_y - p.y) + 1
                if 0 <= grid_y < height and 0 <= grid_x < width:
                    grid[grid_y][grid_x] = ''

            visual = "\n".join(["".join(row) for row in grid])
            return visual

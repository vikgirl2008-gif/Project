class Reactor(SpaceShip):

    def __init__(self, name: str, mass: float, max_energy: float):
        super().__init__(name, mass)
        self.max_energy = max_energy
        self.energy = max_energy
        self.energy_drain = 5.0

    def consume_energy(self, amount: float) -> bool:
        if self.energy >= amount:
            self.energy -= amount
            return True
        return False

    def recharge(self, amount: float):
        self.energy = min(self.max_energy, self.energy + amount)

    def update(self, dt: float):
        self.update_physics(dt)
        self.recharge(2.0 * dt)
class SpaceShip:

    def __init__(self, name: str, mass: float):
        self.name = name
        self.mass = mass

        self.x, self.y = 0.0, 0.0
        self.vx, self.vy = 0.0, 0.0

        self.ax, self.ay = 0.0, 0.0

    def apply_thrust(self, fx: float, fy: float):
        self.ax += fx / self.mass
        self.ay += fy / self.mass

    def update_physics(self, dt: float):
        self.vx += self.ax * dt
        self.vy += self.ay * dt
        self.x += self.vx * dt
        self.y += self.vy * dt

        self.ax, self.ay = 0.0, 0.0

    def get_status(self) -> str:
        return (f"[{self.name}] Pos: ({self.x:.1f}, {self.y:.1f}) | "
                f"Vel: ({self.vx:.1f}, {self.vy:.1f}) | Mass: {self.mass}t")

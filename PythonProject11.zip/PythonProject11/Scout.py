class Scout(Reactor):

    def __init__(self, name: str):
        super().__init__(name, mass=20.0, max_energy=100.0)
        self.scan_range = 500.0

        hull_points = [
            HullPoint(0, 3),
            HullPoint(2, 0),
            HullPoint(0, -2),
            HullPoint(-2, 0),
            HullPoint(0, 1)
        ]
        self.hull = HullCollision(hull_points)

    def thrust(self, direction: str, power: float, dt: float) -> bool:
        energy_cost = power * self.energy_drain * dt
        if not self.consume_energy(energy_cost):
            return False

        force = power * 50

        if direction == "w":
            self.apply_thrust(0, force)
        elif direction == "s":
            self.apply_thrust(0, -force)
        elif direction == "a":
            self.apply_thrust(-force, 0)
        elif direction == "d":
            self.apply_thrust(force, 0)

        return True

    def scan(self):
        print(f"\nАктивирую глубокий скан...")
        print(f"Радиус: {self.scan_range} км. Аномалий не обнаружено.")
        print(f"Расход энергии: 10 единиц.")
        self.consume_energy(10)

    def visualize_hull(self):
        print("\n" + "=" * 30)
        print("Визуализация габаритов корпуса:")
        print(self.hull.visualize())
        min_x, max_x, min_y, max_y = self.hull.get_bounding_box()
        print(f"Габариты: {max_x - min_x}x{max_y - min_y}.")
        print("=" * 30 + "\n")
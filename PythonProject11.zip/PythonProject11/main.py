import time
import math
import pygame

class Main:
    def __init__(self, points: list[HullPoint]):
        self.points = points

def main():
            print("Космическая Академия. Тренажёр пилотов-разведчиков v0.1")
            print("Инициализация систем...")
            time.sleep(1)

            ship = Scout("Scout-Alpha")
            ship.visualize_hull()

            dt = 0.5
            is_running = True

            print("\nУправление:")
            print("w/a/s/d - Тяга (вверх/влево/вниз/вправо)")
            print("scan - Включить сканер")
            print("hull - Показать габариты корпуса")
            print("status - Телеметрия")
            print("exit - Завершить симуляцию\n")

            while is_running:
                print("-" * 40)
                print(f"Энергия: {ship.energy:.1f}/{ship.max_energy} | Координаты: X:{ship.x:.1f}, Y:{ship.y:.1f}")
                command = input("Команда пилота > ").strip().lower()

                match command:
                    case "w" | "a" | "s" | "d":
                        if ship.thrust(command, power=1.0, dt=dt):
                            ship.update(dt)
                            print(f"Тяга применена. Скорость: {math.hypot(ship.vx, ship.vy):.2f} u/s")
                        else:
                            print("Ошибка: Недостаточно энергии для маневра!")

                    case "scan":
                        ship.scan()

                    case "hull":
                        ship.visualize_hull()

                    case "status":
                        print("\n" + ship.get_status())
                        print(f"Энергия: {ship.energy:.1f}/{ship.max_energy}\n")

                    case "exit" | "quit":
                        print("Завершение симуляции. Отключение реактора...")
                        is_running = False

                    case _:
                        print("Неизвестная команда. Повторите ввод.")

if __name__ == "__main__":
    main()



